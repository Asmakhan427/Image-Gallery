// Global variables
let currentImageIndex = 0
let currentImages = []
let allImages = []

// Initialize the gallery when the page loads
document.addEventListener("DOMContentLoaded", () => {
  initializeGallery()
  setupEventListeners()
})

function initializeGallery() {
  // Get all images
  const imageElements = document.querySelectorAll(".pic img")
  allImages = Array.from(imageElements).map((img) => ({
    src: img.src,
    alt: img.alt,
    category: img.parentElement.dataset.category,
  }))

  // Set initial current images to all images
  currentImages = [...allImages]
  updateImageCounter()

  // Add click event listeners to all image containers
  document.querySelectorAll(".pic").forEach((pic, index) => {
    pic.addEventListener("click", () => {
      openLightbox(index)
    })
  })
}

function setupEventListeners() {
  // Radio button change listeners for filtering
  document.querySelectorAll('input[name="photos"]').forEach((radio) => {
    radio.addEventListener("change", () => {
      updateCurrentImages()
    })
  })

  // Keyboard navigation
  document.addEventListener("keydown", (e) => {
    if (document.getElementById("lightbox").classList.contains("active")) {
      if (e.key === "ArrowLeft") {
        changeImage(-1)
      } else if (e.key === "ArrowRight") {
        changeImage(1)
      } else if (e.key === "Escape") {
        closeLightbox()
      }
    }
  })

  // Close lightbox when clicking outside the image
  document.getElementById("lightbox").addEventListener("click", function (e) {
    if (e.target === this) {
      closeLightbox()
    }
  })
}

function updateCurrentImages() {
  const checkedRadio = document.querySelector('input[name="photos"]:checked')
  const filterId = checkedRadio.id

  switch (filterId) {
    case "check1": // All Photos
      currentImages = [...allImages]
      break
    case "check2": // Family Photos
      currentImages = allImages.filter((img) => img.category === "family")
      break
    case "check3": // Child Photos
      currentImages = allImages.filter((img) => img.category === "child")
      break
    case "check4": // Visited Photos
      currentImages = allImages.filter((img) => img.category === "place")
      break
  }

  updateImageCounter()
}

function openLightbox(imageIndex) {
  // Update current images based on current filter
  updateCurrentImages()

  // Find the correct index in the filtered images
  const clickedImage = allImages[imageIndex]
  const filteredIndex = currentImages.findIndex((img) => img.src === clickedImage.src && img.alt === clickedImage.alt)

  if (filteredIndex !== -1) {
    currentImageIndex = filteredIndex
    showImage()
    document.getElementById("lightbox").style.display = "flex"
    setTimeout(() => {
      document.getElementById("lightbox").classList.add("active")
    }, 10)

    // Prevent body scrolling
    document.body.style.overflow = "hidden"
  }
}

function closeLightbox() {
  const lightbox = document.getElementById("lightbox")
  lightbox.classList.remove("active")
  setTimeout(() => {
    lightbox.style.display = "none"
  }, 300)

  // Restore body scrolling
  document.body.style.overflow = "auto"
}

function changeImage(direction) {
  currentImageIndex += direction

  // Loop around if at the beginning or end
  if (currentImageIndex < 0) {
    currentImageIndex = currentImages.length - 1
  } else if (currentImageIndex >= currentImages.length) {
    currentImageIndex = 0
  }

  showImage()
}

function showImage() {
  if (currentImages.length > 0) {
    const lightboxImg = document.getElementById("lightbox-img")
    const currentImage = currentImages[currentImageIndex]

    // Add fade effect
    lightboxImg.style.opacity = "0"

    setTimeout(() => {
      lightboxImg.src = currentImage.src
      lightboxImg.alt = currentImage.alt
      lightboxImg.style.opacity = "1"
    }, 150)

    updateImageCounter()
    updateNavigationButtons()
  }
}

function updateImageCounter() {
  document.getElementById("current-image").textContent = currentImageIndex + 1
  document.getElementById("total-images").textContent = currentImages.length
}

function updateNavigationButtons() {
  const prevBtn = document.querySelector(".nav-buttons button:first-child")
  const nextBtn = document.querySelector(".nav-buttons button:last-child")

  // Disable buttons if there's only one image
  if (currentImages.length <= 1) {
    prevBtn.disabled = true
    nextBtn.disabled = true
  } else {
    prevBtn.disabled = false
    nextBtn.disabled = false
  }
}

// Touch/swipe support for mobile
let touchStartX = 0
let touchEndX = 0

document.getElementById("lightbox").addEventListener("touchstart", (e) => {
  touchStartX = e.changedTouches[0].screenX
})

document.getElementById("lightbox").addEventListener("touchend", (e) => {
  touchEndX = e.changedTouches[0].screenX
  handleSwipe()
})

function handleSwipe() {
  const swipeThreshold = 50
  const diff = touchStartX - touchEndX

  if (Math.abs(diff) > swipeThreshold) {
    if (diff > 0) {
      // Swiped left - next image
      changeImage(1)
    } else {
      // Swiped right - previous image
      changeImage(-1)
    }
  }
}
